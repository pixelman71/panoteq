<?php
/**
 * 2007-2018 ETS-Soft
 *
 * NOTICE OF LICENSE
 *
 * This file is not open source! Each license that you purchased is only available for 1 wesite only.
 * If you want to use this file on more websites (or projects), you need to purchase additional licenses.
 * You are not allowed to redistribute, resell, lease, license, sub-license or offer our resources to any third party.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future. If you wish to customize PrestaShop for your
 * needs please contact us for extra customization service at an affordable price
 *
 * @author ETS-Soft <etssoft.jsc@gmail.com>
 * @copyright  2007-2018 ETS-Soft
 * @license    Valid for 1 website (or project) for each purchase of license
 *  International Registered Trademark & Property of ETS-Soft
 */

if (!defined('_PS_VERSION_'))
    exit;
include_once(_PS_MODULE_DIR_ . 'ets_pres2presconnector/classes/DataExport.php');
include_once(_PS_MODULE_DIR_ . 'ets_pres2presconnector/classes/ExtraExport.php');
if (version_compare(_PS_VERSION_, '1.5', '<') && !class_exists('Context'))
    require_once(_PS_MODULE_DIR_ . '/ets_pres2presconnector/backward_compatibility/Context.php');

class Ets_pres2presconnector extends Module
{
    private $errorMessage;
    public $configs;
    public $baseAdminPath;
    private $_html;
    public $url_module;
    public $errors = array();
    public $tables;
    public $data_exports = '';
    public $divide_file = 1;
    public $number_record = 500;
    public $pres_version;
    public $context;

    public function __construct()
    {
        $this->name = 'ets_pres2presconnector';
        $this->tab = 'front_office_features';
        $this->version = '2.0.2';
        $this->author = 'ETS-Soft';
        $this->need_instance = 0;
        $this->secure_key = Tools::encrypt($this->name);
        $this->bootstrap = true;
        $this->module_key = '8c4686a2fe6d643fe0dea93e2e0a7082';
        if (version_compare(_PS_VERSION_, '1.7', '>='))
            $this->pres_version = 1.7;
        elseif (version_compare(_PS_VERSION_, '1.7', '<') && version_compare(_PS_VERSION_, '1.6', '>='))
            $this->pres_version = 1.6;
        elseif (version_compare(_PS_VERSION_, '1.6', '<') && version_compare(_PS_VERSION_, '1.5', '>='))
            $this->pres_version = 1.5;
        elseif (version_compare(_PS_VERSION_, '1.5', '<') && version_compare(_PS_VERSION_, '1.4', '>='))
            $this->pres_version = 1.4;
        else
            $this->pres_version = 1.3;
        if ($this->pres_version <= 1.4)
            $this->data_exports = 'employees,categories,customers,manufactures,suppliers,carriers,vouchers,products,orders,CMS_categories,CMS,messages';
        else {
            if (Tools::isSubmit('exportallshop') || (Configuration::get('PS_MULTISHOP_FEATURE_ACTIVE') && Shop::getContext() == Shop::CONTEXT_ALL))
                $this->data_exports = 'shops,employees,categories,customers,manufactures,suppliers,carriers,cart_rules,catelog_rules,products,orders,CMS_categories,CMS,messages';
            else
                $this->data_exports = 'employees,categories,customers,manufactures,suppliers,carriers,cart_rules,catelog_rules,products,orders,CMS_categories,CMS,messages';
        }

        parent::__construct();
        $this->context = Context::getContext();
        $this->url_module = $this->_path;
        $this->displayName = $this->l('Prestashop connector');
        $this->description = $this->l('Connect Prestashop websites for migration purpose!');
        if ($this->pres_version == '1.4') {
            global $smarty;
            global $cookie;
            $this->context->smarty = $smarty;
            $this->context->cookie = $cookie;
        }
    }

    /**
     * @see Module::install()
     */
    public function install()
    {
        Configuration::updateValue('ETS_PRES2PRES_TOCKEN', $this->genSecure(6));
        Configuration::updateValue('ETS_PRES2PRES_CONNECTOR', 1);
        if ($this->pres_version == 1.4) {
            if (parent::install() && $this->registerHook('header')) {
                chmod(dirname(__FILE__) . '/connector.php', 0644);
                chmod(dirname(__FILE__) . '/../ets_pres2presconnector', 0755);
                return true;
            }
        } else {
            if (parent::install()
                && $this->registerHook('displayBackOfficeHeader') && $this->registerHook('header')
                && $this->registerHook('displayBackOfficeFooter')) {
                chmod(dirname(__FILE__) . '/connector.php', 0644);
                chmod(dirname(__FILE__) . '/../ets_pres2presconnector', 0755);
                return true;
            }

        }
        return false;
    }

    /**
     * @see Module::uninstall()
     */
    public function uninstall()
    {
        Configuration::deleteByName('ETS_PRES2PRES_TOCKEN');
        Configuration::deleteByName('ETS_PRES2PRES_CONNECTOR');
        return parent::uninstall();
    }

    public function hookHeader()
    {
        if (Tools::isSubmit('presconnector') && Tools::getValue('pres2prestocken') == Configuration::get('ETS_PRES2PRES_TOCKEN') && Configuration::get('ETS_PRES2PRES_CONNECTOR'))
            $this->processExport();
    }

    public function getContent()
    {
        if (!$this->active)
            return '';
        $errors = array();
        $html = '';
        @ini_set('display_errors', 'on');
        $context = Context::getContext();
        if (Tools::isSubmit('btnSubmit')) {
            if (!Tools::getValue('ETS_PRES2PRES_TOCKEN')) {
                $errors[] = $this->l('Secure access token is required');
                $html .= $this->displayError($errors);
            } else {
                Configuration::updateValue('ETS_PRES2PRES_CONNECTOR', Tools::getValue('ETS_PRES2PRES_CONNECTOR'));
                Configuration::updateValue('ETS_PRES2PRES_TOCKEN', Tools::getValue('ETS_PRES2PRES_TOCKEN'));
                Configuration::updateValue('ETS_PRES2PRES_ORDER_FROM', Tools::getValue('ETS_PRES2PRES_ORDER_FROM'));
                Configuration::updateValue('ETS_PRES2PRES_ORDER_TO', Tools::getValue('ETS_PRES2PRES_ORDER_TO'));
                $html .= $this->displayConfirmation($this->l('Settings updated'));
            }
        }
        if (Tools::isSubmit('ajax_percentage_export')) {
            $this->ajaxPercentageExport();
        }
        if (Tools::isSubmit('btnSubmitDownload')) {
            if ($this->pres_version <= 1.4)
                $this->data_exports = 'employees,categories,customers,manufactures,suppliers,carriers,vouchers,products,orders,CMS_categories,CMS,messages';
            else {
                if (Configuration::get('PS_MULTISHOP_FEATURE_ACTIVE') && Shop::getContext() == Shop::CONTEXT_ALL)
                    $this->data_exports = 'shops,employees,categories,customers,manufactures,suppliers,carriers,cart_rules,catelog_rules,products,orders,CMS_categories,CMS,messages';
                else
                    $this->data_exports = 'employees,categories,customers,manufactures,suppliers,carriers,cart_rules,catelog_rules,products,orders,CMS_categories,CMS,messages';
            }
            $this->processExport();
        }
        if ($this->pres_version == 1.4) {
            $connector_url = (self::usingSecureMode() ? 'https://' . Configuration::get('PS_SHOP_DOMAIN_SSL') : 'http://' . Configuration::get('PS_SHOP_DOMAIN')) . __PS_BASE_URI__ . 'modules/' . $this->name . '/connector.php';
        } else {
            $connector_url = (Tools::usingSecureMode() ? 'https://' : 'http://') . $context->shop->domain . $context->shop->getBaseURI() . 'modules/' . $this->name . '/connector.php' . (Configuration::get('PS_MULTISHOP_FEATURE_ACTIVE') && Shop::getContext() == Shop::CONTEXT_ALL ? '?exportallshop=1' : '');
        }
        $context->smarty->assign(
            array(
                'ETS_PRES2PRES_CONNECTOR' => Tools::getValue('ETS_PRES2PRES_CONNECTOR', Configuration::get('ETS_PRES2PRES_CONNECTOR')),
                'ETS_PRES2PRES_TOCKEN' => Tools::getValue('ETS_PRES2PRES_TOCKEN', Configuration::get('ETS_PRES2PRES_TOCKEN')),
                'ETS_PRES2PRES_ORDER_FROM' => Tools::getValue('ETS_PRES2PRES_ORDER_FROM', Configuration::get('ETS_PRES2PRES_ORDER_FROM')),
                'ETS_PRES2PRES_ORDER_TO' => Tools::getValue('ETS_PRES2PRES_ORDER_TO', Configuration::get('ETS_PRES2PRES_ORDER_TO')),
                'connector_url' => $connector_url,
                'dir_path' => $this->_path,
                'pres_version' => $this->pres_version,
            )
        );
        return $html . $this->display(__FILE__, 'views/templates/hook/admin.tpl');
    }

    public function hookDisplayBackOfficeHeader()
    {
        $this->context->controller->addCSS($this->_path . 'views/css/admin-icon.css', 'all');
        if (Tools::isSubmit('controller') && Tools::getValue('controller') == 'AdminModules' && Tools::getValue('configure') == $this->name) {
            $this->context->controller->addCSS($this->_path . 'views/css/pres2presconnector.admin.css', 'all');
            if ($this->pres_version == 1.5) {
                $this->context->controller->addCSS($this->_path . 'views/css/font-awesome.css', 'all');
                $this->context->controller->addCSS($this->_path . 'views/css/fic14.css', 'all');
            }
            $this->context->controller->addJquery();
            if ($this->pres_version <= 1.5) {
                $this->context->controller->addJqueryUI('ui.datepicker');
            }
            $this->context->controller->addJS($this->_path . 'views/js/pres2presconnector.admin.js');
            $this->context->controller->addJS($this->_path . 'views/js/easytimer.min.js');
            $this->context->controller->addJS($this->_path . 'views/js/tree.js');
        }
    }

    public function displayError($error)
    {
        $this->context->smarty->assign(
            array(
                'ybc_errors' => $error,
            )
        );
        return $this->display(__FILE__, 'views/templates/hook/errors.tpl');
    }

    public function exportContent($save = true)
    {
        $data_exports = explode(',', $this->data_exports);
        $contents = array();
        $totaldatas = array();
        if (in_array('shops', $data_exports)) {
            $countShop = Db::getInstance()->getValue('SELECT count(*) FROM ' . _DB_PREFIX_ . 'shop');
            $contents[] = array(
                'title' => $this->l('Shops:'),
                'count' => $countShop,
            );
            $totaldatas['shops'] = (int)$countShop;
        }
        if (in_array('employees', $data_exports)) {
            $countEmployee = Db::getInstance()->getValue('SELECT count(*) FROM ' . _DB_PREFIX_ . 'employee');
            $contents[] = array(
                'title' => $this->l('Employees:'),
                'count' => $countEmployee,
            );
            $totaldatas['employees'] = (int)$countEmployee;

        }
        if (in_array('categories', $data_exports)) {
            $countCategory = Db::getInstance()->getValue('SELECT count(*) FROM ' . _DB_PREFIX_ . 'category');
            $contents[] = array(
                'title' => $this->l('Categories:'),
                'count' => $countCategory,
            );
            $totaldatas['categories'] = (int)$countCategory;
        }
        if (in_array('products', $data_exports)) {
            $countProduct = Db::getInstance()->getValue('SELECT count(*) FROM ' . _DB_PREFIX_ . 'product');
            $contents[] = array(
                'title' => $this->l('Products:'),
                'count' => $countProduct,
            );
            $totaldatas['products'] = (int)$countProduct;
        }
        if (in_array('customers', $data_exports)) {
            $countCustomer = Db::getInstance()->getValue('SELECT count(*) FROM ' . _DB_PREFIX_ . 'customer WHERE deleted=0');
            $contents[] = array(
                'title' => $this->l('Customers:'),
                'count' => $countCustomer,
            );
            $totaldatas['customers'] = (int)$countCustomer;
        }
        if (in_array('orders', $data_exports)) {
            $countOrder = Db::getInstance()->getValue('SELECT count(*) FROM ' . _DB_PREFIX_ . 'orders');
            $contents[] = array(
                'title' => $this->l('Orders:'),
                'count' => $countOrder,
            );
            $totaldatas['orders'] = (int)$countOrder;
        }
        if (in_array('manufactures', $data_exports)) {
            $countManufacturer = Db::getInstance()->getValue('SELECT count(*) FROM ' . _DB_PREFIX_ . 'manufacturer');
            $contents[] = array(
                'title' => $this->l('Manufacturers:'),
                'count' => $countManufacturer,
            );
            $totaldatas['manufactures'] = (int)$countManufacturer;
        }
        if (in_array('suppliers', $data_exports)) {
            $countSupplier = Db::getInstance()->getValue('SELECT count(*) FROM ' . _DB_PREFIX_ . 'supplier');
            $contents[] = array(
                'title' => $this->l('Suppliers:'),
                'count' => $countSupplier,
            );
            $totaldatas['suppliers'] = (int)$countSupplier;
        }
        if (in_array('carriers', $data_exports)) {
            $countCarrier = Db::getInstance()->getValue('SELECT count(*) FROM ' . _DB_PREFIX_ . 'carrier WHERE deleted=0');
            $contents[] = array(
                'title' => $this->l('Carriers:'),
                'count' => $countCarrier,
            );
            $totaldatas['carriers'] = (int)$countCarrier;
        }
        if (in_array('cart_rules', $data_exports)) {
            $countCartRule = Db::getInstance()->getValue('SELECT count(*) FROM ' . _DB_PREFIX_ . 'cart_rule');
            $contents[] = array(
                'title' => $this->l('Cart rules:'),
                'count' => $countCartRule,
            );
            $totaldatas['cart_rules'] = (int)$countCartRule;
        }
        if (in_array('catelog_rules', $data_exports)) {
            $countSpecificPriceRule = Db::getInstance()->getValue('SELECT count(*) FROM ' . _DB_PREFIX_ . 'specific_price_rule');
            $contents[] = array(
                'title' => $this->l('Catelog rules:'),
                'count' => $countSpecificPriceRule,
            );
            $totaldatas['catelog_rules'] = (int)$countSpecificPriceRule;
        }
        if (in_array('vouchers', $data_exports)) {
            $countVoucher = Db::getInstance()->getValue('SELECT count(*) FROM ' . _DB_PREFIX_ . 'discount');
            $contents[] = array(
                'title' => $this->l('Vouchers:'),
                'count' => $countVoucher,
            );
            $totaldatas['vouchers'] = (int)$countVoucher;
        }
        if (in_array('CMS_categories', $data_exports)) {
            $countcmscategory = Db::getInstance()->getValue('SELECT count(*) FROM ' . _DB_PREFIX_ . 'cms_category');
            $contents[] = array(
                'title' => $this->l('CMS categories:'),
                'count' => $countcmscategory,
            );
            $totaldatas['CMS_categories'] = (int)$countcmscategory;
        }
        if (in_array('CMS', $data_exports)) {
            $countcms = Db::getInstance()->getValue('SELECT count(*) FROM ' . _DB_PREFIX_ . 'cms');
            $contents[] = array(
                'title' => $this->l('CMSs:'),
                'count' => $countcms,
            );
            $totaldatas['CMS'] = (int)$countcms;
        }
        if (in_array('messages', $data_exports)) {
            $countMessage = Db::getInstance()->getValue('SELECT count(*) FROM ' . _DB_PREFIX_ . 'customer_thread');
            $contents[] = array(
                'title' => $this->l('Contact form messages:'),
                'count' => $countMessage,
            );
            $totaldatas['messages'] = (int)$countMessage;
        }
        if ($save) {
            $this->context->smarty->assign(
                array(
                    'contents' => $contents
                )
            );
            return $this->display(__FILE__, 'views/templates/hook/contents.tpl');
        } else
            return $totaldatas;
    }

    public function processExport()
    {
        if ($this->pres_version == 1.4)
            $this->exportDataXML14();
        else
            $this->exportDataXML();
    }

    public function exportDataXML()
    {
        $export = new Pres2PresConnectorExport();
        $extra_export = new Pres2PresConnectorExtraExport();
        $cacheDir = dirname(__FILE__) . '/cache/export/';
        if (Tools::getValue('zip_file_name'))
            $zip_file_name = Tools::getValue('zip_file_name');
        else {
            if (!Tools::getValue('submitExportReload')) {
                $this->context->cookie->zip_file_name = '';
                $this->context->cookie->export_sucss = '';
                $this->context->cookie->write();
            }
            $cacheDir = dirname(__FILE__) . '/cache/export/';
            if (isset($this->context->cookie->zip_file_name) && $this->context->cookie->zip_file_name) {
                $zip_file_name = $this->context->cookie->zip_file_name;
            } else {
                $zip_file_name = 'oc2m_data_' . $this->genSecure(7);
                $this->context->cookie->zip_file_name = $zip_file_name;
                $this->context->cookie->write();
                die('Oops. Your jQuery is out of date. Please upgrade your jQuery to jQuery -1.1.11');
            }
        }
        $dir = $cacheDir . $zip_file_name;

        if (!is_dir($dir)) {
            @mkdir($dir, 0777);
            file_put_contents($dir . '/export.txt', '0');
            $export->total_export = 0;
        } else
            $export->total_export = (int)trim(file_get_contents($dir . '/export.txt'));
        if (file_exists($cacheDir . $zip_file_name . '.zip')) {
            $this->deleteForderXml($zip_file_name);
        }
        $data_exports = explode(',', $this->data_exports);
        $multishop = in_array('shops', $data_exports);
        if (!file_exists($dir . '/DataInfo.xml'))
            file_put_contents($dir . '/DataInfo.xml', $extra_export->exportInfo($dir));
        if ($data_exports) {
            if ($multishop) {
                if ($this->checkTableExported($dir, 'ShopGroup')) {
                    if (!$export->addFileXMl($dir, 'ShopGroup', ShopGroup::$definition, $multishop))
                        $this->_errors[] = $this->l('Cannot create ShopGroup.xml');
                    else
                        $this->insertTableExported($dir, 'ShopGroup');
                }
                if ($this->checkTableExported($dir, 'shop')) {
                    if (!$export->addFileXMl($dir, 'Shop', Shop::$definition, $multishop))
                        $this->_errors[] = $this->l('Cannot create Shop.xml');
                    else
                        $this->insertTableExported($dir, 'shop');
                }
                if ($this->checkTableExported($dir, 'ShopUrl')) {
                    if (!$export->addFileXMl($dir, 'ShopUrl', ShopUrl::$definition, $multishop))
                        $this->_errors[] = $this->l('Cannot create ShopUrl.xml');
                    else
                        $this->insertTableExported($dir, 'ShopUrl');
                }
            }
            if ($this->checkTableExported($dir, 'Language')) {
                if (!$export->addFileXMl($dir, 'Language', Language::$definition, $multishop))
                    $this->_errors[] = $this->l('Cannot create Language.xml');
                else
                    $this->insertTableExported($dir, 'Language');
            }
            if ($this->checkTableExported($dir, 'Currency')) {
                if (!$export->addFileXMl($dir, 'Currency', Currency::$definition, $multishop))
                    $this->_errors[] = $this->l('Cannot create Currency.xml');
                else
                    $this->insertTableExported($dir, 'Currency');
            }
            if ($this->checkTableExported($dir, 'Zone')) {
                if (!$export->addFileXMl($dir, 'Zone', Zone::$definition, $multishop))
                    $this->_errors[] = $this->l('Cannot create Zone.xml');
                else
                    $this->insertTableExported($dir, 'Zone');
            }
            if ($this->checkTableExported($dir, 'Country')) {
                if (!$export->addFileXMl($dir, 'Country', Country::$definition, $multishop))
                    $this->_errors[] = $this->l('Cannot create Country.xml');
                else
                    $this->insertTableExported($dir, 'Country');
            }
            if ($this->checkTableExported($dir, 'State')) {
                if (!$export->addFileXMl($dir, 'State', State::$definition, $multishop))
                    $this->_errors[] = $this->l('Cannot create State.xml');
                else
                    $this->insertTableExported($dir, 'State');
            }
            if ($this->checkTableExported($dir, 'Employee')) {
                if (!$export->addFileXMl($dir, 'Employee', Employee::$definition, $multishop))
                    $this->_errors[] = $this->l('Cannot create Employee.xml');
                else
                    $this->insertTableExported($dir, 'Employee');
            }

            if (in_array('categories', $data_exports)) {
                if ($this->checkTableExported($dir, 'Group')) {
                    if (!$export->addFileXMl($dir, 'Group', Group::$definition, $multishop))
                        $this->_errors[] = $this->l('Cannot create Group.xml');
                    else
                        $this->insertTableExported($dir, 'Group');
                }
                if ($this->checkTableExported($dir, 'Category')) {
                    if (!$this->addCategoryFileXMl($dir, $multishop))
                        $this->_errors[] = $this->l('Cannot create Category.xml');
                    else
                        $this->insertTableExported($dir, 'Category');
                }
            }
            if (in_array('customers', $data_exports)) {
                if ($this->checkTableExported($dir, 'Group')) {
                    if (!$export->addFileXMl($dir, 'Group', Group::$definition, $multishop))
                        $this->_errors[] = $this->l('Cannot create Group.xml');
                    else
                        $this->insertTableExported($dir, 'Group');
                }
                if ($this->checkTableExported($dir, 'Customer')) {
                    if (!$export->addFileXMl($dir, 'Customer', Customer::$definition, $multishop))
                        $this->_errors[] = $this->l('Cannot create Customer.xml');
                    else
                        $this->insertTableExported($dir, 'Customer');
                }
                if ($this->checkTableExported($dir, 'customer_group')) {
                    if (!$export->addFileXMl14($dir, 'customergroup', 'customer_group')) {
                        $this->_errors[] = $this->l('Cannot create customergroup.xml');
                    } else
                        $this->insertTableExported($dir, 'customer_group');
                }
                if ($this->checkTableExported($dir, 'Address')) {
                    if (!$export->addFileXMl($dir, 'Address', Address::$definition, $multishop))
                        $this->_errors[] = $this->l('Cannot create Address.xml');
                    else
                        $this->insertTableExported($dir, 'Address');
                }
            }
            if (in_array('manufactures', $data_exports)) {
                if ($this->checkTableExported($dir, 'Manufacturer')) {
                    if (!$export->addFileXMl($dir, 'Manufacturer', Manufacturer::$definition, $multishop))
                        $this->_errors[] = $this->l('Cannot create Manufacturer.xml');
                    else
                        $this->insertTableExported($dir, 'Manufacturer');
                }
            }
            if (in_array('suppliers', $data_exports)) {
                if ($this->checkTableExported($dir, 'Supplier')) {
                    if (!$export->addFileXMl($dir, 'Supplier', Supplier::$definition, $multishop))
                        $this->_errors[] = $this->l('Cannot create Supplier.xml');
                    else
                        $this->insertTableExported($dir, 'Supplier');
                }
            }
            if (in_array('carriers', $data_exports)) {
                if ($this->checkTableExported($dir, 'Carrier')) {
                    if (!$export->addFileXMl($dir, 'Carrier', Carrier::$definition, $multishop))
                        $this->_errors[] = $this->l('Cannot create Carrier.xml');
                    else
                        $this->insertTableExported($dir, 'Carrier');
                }
                if ($this->checkTableExported($dir, 'carrierzone')) {
                    if (!$export->addFileXMl14($dir, 'carrierzone', 'carrier_zone')) {
                        $this->_errors[] = $this->l('Cannot create carrierzone.xml');
                    } else
                        $this->insertTableExported($dir, 'carrierzone');
                }
                if ($this->checkTableExported($dir, 'RangePrice')) {
                    if (!$export->addFileXMl($dir, 'RangePrice', RangePrice::$definition, $multishop))
                        $this->_errors[] = $this->l('Cannot create RangePrice.xml');
                    else
                        $this->insertTableExported($dir, 'RangePrice');
                }
                if ($this->checkTableExported($dir, 'RangeWeight')) {
                    if (!$export->addFileXMl($dir, 'RangeWeight', RangeWeight::$definition, $multishop))
                        $this->_errors[] = $this->l('Cannot create RangeWeight.xml');
                    else
                        $this->insertTableExported($dir, 'RangeWeight');
                }
                if ($this->checkTableExported($dir, 'Delivery')) {
                    if (!$export->addFileXMl($dir, 'Delivery', Delivery::$definition, $multishop))
                        $this->_errors[] = $this->l('Cannot create Delivery.xml');
                    else
                        $this->insertTableExported($dir, 'Delivery');
                }
            }
            if (in_array('cart_rules', $data_exports)) {
                if ($this->checkTableExported($dir, 'CartRule')) {
                    if (!$export->addFileXMl($dir, 'CartRule', CartRule::$definition, $multishop))
                        $this->_errors[] = $this->l('Cannot create CartRule.xml');
                    else
                        $this->insertTableExported($dir, 'CartRule');
                }
                if ($this->checkTableExported($dir, 'cartrulecarrier')) {
                    if (!$export->addFileXMl14($dir, 'cartrulecarrier', 'cart_rule_carrier')) {
                        $this->_errors[] = $this->l('Cannot create cartrulecarrier.xml');  //extra
                    } else
                        $this->insertTableExported($dir, 'cartrulecarrier');
                }
                if (!$export->addFileXMl14($dir, 'cartrulecombination ', 'cart_rule_combination')) {
                    $this->_errors[] = $this->l('Cannot create cartrulecombination.xml');  //extra
                } else
                    $this->insertTableExported($dir, 'cartrulecombination');
                if (!$export->addFileXMl14($dir, 'cartrulecountry ', 'cart_rule_country ')) {
                    $this->_errors[] = $this->l('Cannot create cartrulecountry.xml');  //extra
                } else
                    $this->insertTableExported($dir, 'cartrulecountry');
                if (!$export->addFileXMl14($dir, 'cartrulegroup', 'cart_rule_group')) {
                    $this->_errors[] = $this->l('Cannot create cartrulegroup.xml');  //extra
                } else
                    $this->insertTableExported($dir, 'cartrulegroup');
                if (!$export->addFileXMl14($dir, 'cartruleproductrulegroup', 'cart_rule_product_rule_group')) {
                    $this->_errors[] = $this->l('Cannot create cartruleproductrulegroup.xml');  //extra
                } else
                    $this->insertTableExported($dir, 'cartruleproductrulegroup');

                if (!$export->addFileXMl14($dir, 'cartruleproductrule', 'cart_rule_product_rule')) {
                    $this->_errors[] = $this->l('Cannot create cartruleproductrule.xml');  //extra
                } else
                    $this->insertTableExported($dir, 'cartruleproductrule');

                if (!$export->addFileXMl14($dir, 'cartruleproductrulevalue', 'cart_rule_product_rule_value')) {
                    $this->_errors[] = $this->l('Cannot create cartruleproductrulevalue.xml');  //extra
                } else
                    $this->insertTableExported($dir, 'cartruleproductrulevalue');
            }
            if (in_array('catelog_rules', $data_exports)) {
                if ($this->checkTableExported($dir, 'SpecificPriceRule')) {
                    if (!$export->addFileXMl($dir, 'SpecificPriceRule', SpecificPriceRule::$definition, $multishop))
                        $this->_errors[] = $this->l('Cannot create SpecificPriceRule.xml');
                    else
                        $this->insertTableExported($dir, 'SpecificPriceRule');
                }
            }
            if (in_array('products', $data_exports)) {
                if ($this->checkTableExported($dir, 'categoryproduct')) {
                    if (!$export->addFileXMl14($dir, 'categoryproduct', 'category_product')) {
                        $this->_errors[] = $this->l('Cannot create categoryproduct.xml');  //extra
                    } else
                        $this->insertTableExported($dir, 'categoryproduct');
                }
                if ($this->checkTableExported($dir, 'Product')) {
                    if (!$export->addFileXMl($dir, 'Product', Product::$definition, $multishop))
                        $this->_errors[] = $this->l('Cannot create Product.xml');
                    else
                        $this->insertTableExported($dir, 'Product');
                }
                if ($this->checkTableExported($dir, 'Tag')) {
                    if (!$export->addFileXMl($dir, 'Tag', Tag::$definition, $multishop))
                        $this->_errors[] = $this->l('Cannot create tag.xml');
                    else
                        $this->insertTableExported($dir, 'Tag');
                }
                if ($this->checkTableExported($dir, 'Image')) {
                    if (!$export->addFileXMl($dir, 'Image', Image::$definition, $multishop))
                        $this->_errors[] = $this->l('Cannot create Image.xml');
                    else
                        $this->insertTableExported($dir, 'Image');
                }
                if ($this->checkTableExported($dir, 'Combination')) {
                    if (!$export->addFileXMl($dir, 'Combination', Combination::$definition, $multishop))
                        $this->_errors[] = $this->l('Cannot create Combination.xml');
                    else
                        $this->insertTableExported($dir, 'Combination');
                }
                if ($this->checkTableExported($dir, 'AttributeGroup')) {
                    if (!$export->addFileXMl($dir, 'AttributeGroup', AttributeGroup::$definition, $multishop))
                        $this->_errors[] = $this->l('Cannot create AttributeGroup.xml');
                    else
                        $this->insertTableExported($dir, 'AttributeGroup');
                }
                if ($this->checkTableExported($dir, 'Attribute')) {
                    if (!$export->addFileXMl($dir, 'Attribute', Attribute::$definition, $multishop))
                        $this->_errors[] = $this->l('Cannot create Attribute.xml');
                    else
                        $this->insertTableExported($dir, 'Attribute');
                }
                if ($this->checkTableExported($dir, 'productattributecombination')) {
                    if (!$export->addFileXMl14($dir, 'productattributecombination', 'product_attribute_combination')) {
                        $this->_errors[] = $this->l('Cannot create productattributecombination.xml'); //extra
                    } else
                        $this->insertTableExported($dir, 'productattributecombination');
                }
                if ($this->checkTableExported($dir, 'productattributeimage')) {
                    if (!$export->addFileXMl14($dir, 'productattributeimage', 'product_attribute_image')) {
                        $this->_errors[] = $this->l('Cannot create productattributeimage.xml'); //extra
                    } else
                        $this->insertTableExported($dir, 'productattributeimage');
                }
                if ($this->checkTableExported($dir, 'producttag')) {
                    if (!$export->addFileXMl14($dir, 'producttag', 'product_tag')) {
                        $this->_errors[] = $this->l('Cannot create producttag.xml'); //extra
                    } else
                        $this->insertTableExported($dir, 'producttag');
                }
                if ($this->checkTableExported($dir, 'Feature')) {
                    if (!$export->addFileXMl($dir, 'Feature', Feature::$definition, $multishop))
                        $this->_errors[] = $this->l('Cannot create Feature.xml');
                    else
                        $this->insertTableExported($dir, 'Feature');
                }
                if ($this->checkTableExported($dir, 'FeatureValue')) {
                    if (!$export->addFileXMl($dir, 'FeatureValue', FeatureValue::$definition, $multishop))
                        $this->_errors[] = $this->l('Cannot create FeatureValue.xml');
                    else
                        $this->insertTableExported($dir, 'FeatureValue');
                }
                if ($this->checkTableExported($dir, 'featureproduct')) {
                    if (!$export->addFileXMl14($dir, 'featureproduct', 'feature_product')) {
                        $this->_errors[] = $this->l('Cannot create featureproduct.xml'); // extra feature_product;
                    } else
                        $this->insertTableExported($dir, 'featureproduct');
                }
                if ($this->checkTableExported($dir, 'SpecificPrice')) {
                    if (!$export->addFileXMl($dir, 'SpecificPrice', SpecificPrice::$definition, $multishop))
                        $this->_errors[] = $this->l('Cannot create SpecificPrice.xml');
                    else
                        $this->insertTableExported($dir, 'SpecificPrice');
                }
                if ($this->checkTableExported($dir, 'Tax')) {
                    if (!$export->addFileXMl($dir, 'Tax', Tax::$definition, $multishop))
                        $this->_errors[] = $this->l('Cannot create Tax.xml');
                    else
                        $this->insertTableExported($dir, 'Tax');
                }
                if ($this->checkTableExported($dir, 'TaxRulesGroup')) {
                    if (!$export->addFileXMl($dir, 'TaxRulesGroup', TaxRulesGroup::$definition, $multishop))
                        $this->_errors[] = $this->l('Cannot create TaxRulesGroup.xml');
                    else
                        $this->insertTableExported($dir, 'TaxRulesGroup');
                }
                if ($this->checkTableExported($dir, 'TaxRule')) {
                    if (!$export->addFileXMl($dir, 'TaxRule', TaxRule::$definition, $multishop))
                        $this->_errors[] = $this->l('Cannot create TaxRule.xml');
                    else
                        $this->insertTableExported($dir, 'TaxRule');
                }
                if ($this->checkTableExported($dir, 'productsupplier')) {
                    if (!$export->addFileXMl14($dir, 'productsupplier', 'product_supplier')) {
                        $this->_errors[] = $this->l('Cannot create productsupplier.xml'); // id_tax, id_rules_group
                    } else
                        $this->insertTableExported($dir, 'productsupplier');
                }
                if ($this->checkTableExported($dir, 'StockAvailable')) {
                    if (!$export->addFileXMl($dir, 'StockAvailable', StockAvailable::$definition, $multishop))
                        $this->_errors[] = $this->l('Cannot create StockAvailable.xml');
                    else
                        $this->insertTableExported($dir, 'StockAvailable');
                }
                if ($this->checkTableExported($dir, 'Warehouse')) {
                    if (!$export->addFileXMl($dir, 'Warehouse', Warehouse::$definition, $multishop))
                        $this->_errors[] = $this->l('Cannot create Warehouse.xml');
                    else
                        $this->insertTableExported($dir, 'Warehouse');
                }
                if ($this->checkTableExported($dir, 'WarehouseProductLocation')) {
                    if (!$export->addFileXMl($dir, 'WarehouseProductLocation', WarehouseProductLocation::$definition, $multishop))
                        $this->_errors[] = $this->l('Cannot create WarehouseProductLocation.xml');
                    else
                        $this->insertTableExported($dir, 'WarehouseProductLocation');
                }
                if ($this->checkTableExported($dir, 'Stock')) {
                    if (!$export->addFileXMl($dir, 'Stock', Stock::$definition, $multishop))
                        $this->_errors[] = $this->l('Cannot create Stock.xml');
                    else
                        $this->insertTableExported($dir, 'Stock');
                }
                if ($this->checkTableExported($dir, 'warehousecarrier')) {
                    if (in_array('carriers', $data_exports)) {
                        if (!$export->addFileXMl14($dir, 'warehousecarrier', 'warehouse_carrier')) {
                            $this->_errors[] = $this->l('Cannot create warehousecarrier.xml');
                        } else
                            $this->insertTableExported($dir, 'warehousecarrier');
                    }
                }
                if ($this->checkTableExported($dir, 'CustomizationField')) {
                    if (!$export->addFileXMl14($dir, 'CustomizationField', 'customization_field', 'id_customization_field', true))
                        $this->_errors[] = $this->l('Cannot create CustomizationField.xml');
                    else
                        $this->insertTableExported($dir, 'CustomizationField');
                }
                if ($this->checkTableExported($dir, 'productcarrier')) {
                    if (in_array('carriers', $data_exports)) {
                        if (!$export->addFileXMl14($dir, 'productcarrier', 'product_carrier')) {
                            $this->_errors[] = $this->l('Cannot create productcarrier.xml');
                        } else
                            $this->insertTableExported($dir, 'productcarrier');
                    }
                }
                if ($this->checkTableExported($dir, 'accessory')) {
                    if (!$export->addFileXMl14($dir, 'accessory', 'accessory')) {
                        $this->_errors[] = $this->l('Cannot create accessory.xml'); //extra
                    } else
                        $this->insertTableExported($dir, 'accessory');
                }
                if ($this->checkTableExported($dir, 'pack')) {
                    if (!$export->addFileXMl14($dir, 'pack', 'pack')) {
                        $this->_errors[] = $this->l('Cannot create pack.xml'); //extra
                    } else
                        $this->insertTableExported($dir, 'pack');
                }
            }
            if (in_array('orders', $data_exports)) {
                if ($this->checkTableExported($dir, 'OrderState')) {
                    if (!$export->addFileXMl($dir, 'OrderState', OrderState::$definition, $multishop))
                        $this->_errors[] = $this->l('Cannot create OrderState.xml');
                    else
                        $this->insertTableExported($dir, 'OrderState');
                }
                if ($this->checkTableExported($dir, 'Cart')) {
                    if (!$export->addFileXMl($dir, 'Cart', Cart::$definition, $multishop))
                        $this->_errors[] = $this->l('Cannot create Cart.xml');
                    else
                        $this->insertTableExported($dir, 'Cart');
                }
                if ($this->checkTableExported($dir, 'Customization')) {
                    if (!$export->addFileXMl14($dir, 'Customization', 'customization', 'id_customization'))
                        $this->_errors[] = $this->l('Cannot create CustomizationField.xml');
                    else
                        $this->insertTableExported($dir, 'Customization');
                }
                if ($this->checkTableExported($dir, 'customizeddata')) {
                    if (!$export->addFileXMl14($dir, 'customizeddata', 'customized_data'))
                        $this->_errors[] = $this->l('Cannot create customizeddata.xml');
                    else
                        $this->insertTableExported($dir, 'customizeddata');
                }
                if ($this->checkTableExported($dir, 'Order')) {
                    if (!$export->addFileXMl($dir, 'Order', Order::$definition, $multishop))
                        $this->_errors[] = $this->l('Cannot create Order.xml');
                    else
                        $this->insertTableExported($dir, 'Order');
                }
                if ($this->checkTableExported($dir, 'OrderDetail')) {
                    if (!$export->addFileXMl($dir, 'OrderDetail', OrderDetail::$definition, $multishop))
                        $this->_errors[] = $this->l('Cannot create OrderDetail.xml');
                    else
                        $this->insertTableExported($dir, 'OrderDetail');
                }
                if ($this->checkTableExported($dir, 'OrderInvoice')) {
                    if (!$export->addFileXMl($dir, 'OrderInvoice', OrderInvoice::$definition, $multishop))
                        $this->_errors[] = $this->l('Cannot create OrderInvoice.xml');
                    else
                        $this->insertTableExported($dir, 'OrderInvoice');
                }
                if ($this->checkTableExported($dir, 'order_detail_tax')) {
                    if (!$export->addFileXMl14($dir, 'order_detail_tax', 'order_detail_tax'))
                        $this->_errors[] = $this->l('Cannot create order_detail_tax.xml');
                    else
                        $this->insertTableExported($dir, 'order_detail_tax');
                }
                if ($this->checkTableExported($dir, 'order_invoice_tax')) {
                    if (!$export->addFileXMl14($dir, 'order_invoice_tax', 'order_invoice_tax'))
                        $this->_errors[] = $this->l('Cannot create order_invoice_tax.xml');
                    else
                        $this->insertTableExported($dir, 'order_invoice_tax');
                }
                if ($this->checkTableExported($dir, 'order_invoice_payment')) {
                    if (!$export->addFileXMl14($dir, 'order_invoice_payment', 'order_invoice_payment'))
                        $this->_errors[] = $this->l('Cannot create order_invoice_payment.xml');
                    else
                        $this->insertTableExported($dir, 'order_invoice_payment');
                }
                if ($this->checkTableExported($dir, 'OrderSlip')) {
                    if (!$export->addFileXMl($dir, 'OrderSlip', OrderSlip::$definition, $multishop))
                        $this->_errors[] = $this->l('Cannot create OrderSlip.xml');
                    else
                        $this->insertTableExported($dir, 'OrderSlip');
                }
                if ($this->checkTableExported($dir, 'OrderCarrier')) {
                    if (!$export->addFileXMl($dir, 'OrderCarrier', OrderCarrier::$definition, $multishop))
                        $this->_errors[] = $this->l('Cannot create OrderCarrier.xml');
                    else
                        $this->insertTableExported($dir, 'OrderCarrier');
                }
                if ($this->checkTableExported($dir, 'OrderCartRule')) {
                    if (!$export->addFileXMl($dir, 'OrderCartRule', OrderCartRule::$definition, $multishop))
                        $this->_errors[] = $this->l('Cannot create OrderCartRule.xml');
                    else
                        $this->insertTableExported($dir, 'OrderCartRule');
                }
                if ($this->checkTableExported($dir, 'OrderHistory')) {
                    if (!$export->addFileXMl($dir, 'OrderHistory', OrderHistory::$definition, $multishop))
                        $this->_errors[] = $this->l('Cannot create OrderHistory.xml');
                    else
                        $this->insertTableExported($dir, 'OrderHistory');
                }
                if ($this->checkTableExported($dir, 'OrderMessage')) {
                    if (!$export->addFileXMl($dir, 'OrderMessage', OrderMessage::$definition, $multishop))
                        $this->_errors[] = $this->l('Cannot create OrderMessage.xml');
                    else
                        $this->insertTableExported($dir, 'OrderMessage');
                }
                if ($this->checkTableExported($dir, 'OrderPayment')) {
                    if (!$export->addFileXMl($dir, 'OrderPayment', OrderPayment::$definition, $multishop))
                        $this->_errors[] = $this->l('Cannot create OrderPayment.xml');
                    else
                        $this->insertTableExported($dir, 'OrderPayment');
                }
                if ($this->checkTableExported($dir, 'OrderReturn')) {
                    if (!$export->addFileXMl($dir, 'OrderReturn', OrderReturn::$definition, $multishop))
                        $this->_errors[] = $this->l('Cannot create OrderReturn.xml');
                    else
                        $this->insertTableExported($dir, 'OrderReturn');
                }
                if ($this->checkTableExported($dir, 'Message')) {
                    if (!$export->addFileXMl($dir, 'Message', Message::$definition, $multishop))
                        $this->_errors[] = $this->l('Cannot create Message.xml');
                    else
                        $this->insertTableExported($dir, 'Message');
                }
            }
            if (in_array('CMS_categories', $data_exports)) {
                if ($this->checkTableExported($dir, 'CMSCategory')) {
                    if (!$export->addFileXMl($dir, 'CMSCategory', CMSCategory::$definition, $multishop))
                        $this->_errors[] = $this->l('Cannot create CMSCategory.xml');
                    else
                        $this->insertTableExported($dir, 'CMSCategory');
                }
            }
            if (in_array('CMS', $data_exports)) {
                if ($this->checkTableExported($dir, 'CMS')) {
                    if (!$export->addFileXMl($dir, 'CMS', CMS::$definition, $multishop))
                        $this->_errors[] = $this->l('Cannot create CMS.xml');
                    else
                        $this->insertTableExported($dir, 'CMS');
                }

            }
            if (in_array('messages', $data_exports)) {
                if ($this->checkTableExported($dir, 'Contact')) {
                    if (!$export->addFileXMl($dir, 'Contact', Contact::$definition, $multishop))
                        $this->_errors[] = $this->l('Cannot create Contact.xml');
                    else
                        $this->insertTableExported($dir, 'Contact');
                }
                if ($this->checkTableExported($dir, 'CustomerThread')) {
                    if (!$export->addFileXMl($dir, 'CustomerThread', CustomerThread::$definition, $multishop))
                        $this->_errors[] = $this->l('Cannot create CustomerThread.xml');
                    else
                        $this->insertTableExported($dir, 'CustomerThread');
                }
                if ($this->checkTableExported($dir, 'CustomerMessage')) {
                    if (!$export->addFileXMl($dir, 'CustomerMessage', CustomerMessage::$definition, $multishop))
                        $this->_errors[] = $this->l('Cannot create CustomerMessage.xml');
                    else
                        $this->insertTableExported($dir, 'CustomerMessage');
                }
            }
            if (!$this->_errors) {
                $this->zipForderXml($zip_file_name);
                $content = $this->exportContent();
                $this->deleteForderXml($zip_file_name);
                $this->context->cookie->zip_file_name = '';
                $this->context->cookie->write();
                $this->context->cookie->export_sucss = '';
                return $zip_file_name . '.zip';
            }
        }
        return $this->_errors;
    }

    public function getBaseLink()
    {
        if ($this->pres_version == 1.4) {
            $url = (Configuration::get('PS_SSL_ENABLED') ? 'https://' : 'http://') . Configuration::get('PS_SHOP_DOMAIN') . __PS_BASE_URI__;
        } else
            $url = (Configuration::get('PS_SSL_ENABLED_EVERYWHERE') ? 'https://' : 'http://') . $this->context->shop->domain . $this->context->shop->getBaseURI();
        return trim($url, '/') . '/';
    }

    public function exportDataXML14()
    {
        $cacheDir = dirname(__FILE__) . '/cache/export/';
        if (Tools::getValue('zip_file_name'))
            $zip_file_name = Tools::getValue('zip_file_name');
        else {
            if (!Tools::getValue('submitExportReload')) {
                $this->context->cookie->zip_file_name = '';
                $this->context->cookie->export_sucss = '';
                $this->context->cookie->write();
            }
            $cacheDir = dirname(__FILE__) . '/cache/export/';
            if (isset($this->context->cookie->zip_file_name) && $this->context->cookie->zip_file_name) {
                $zip_file_name = $this->context->cookie->zip_file_name;
            } else {
                $zip_file_name = 'oc2m_data_' . $this->genSecure(7);

                $this->context->cookie->zip_file_name = $zip_file_name;

                $this->context->cookie->write();
                die('Oops. Your jQuery is out of date. Please upgrade your jQuery to jQuery -1.1.11');
            }
        }
        $dir = $cacheDir . $zip_file_name;
        $export = new Pres2PresConnectorExport();
        $extra_export = new Pres2PresConnectorExtraExport();
        if (!is_dir($dir)) {
            @mkdir($dir, 0777);
            file_put_contents($dir . '/export.txt', '0');
        } else
            $export->total_export = (int)trim(file_get_contents($dir . '/export.txt'));
        if (file_exists($cacheDir . $zip_file_name . '.zip')) {
            $this->deleteForderXml($zip_file_name);
        }
        $data_exports = explode(',', $this->data_exports);

        file_put_contents($dir . '/DataInfo.xml', $extra_export->exportInfo($dir));
        if ($data_exports) {

            if ($this->checkTableExported($dir, 'lang')) {
                if (!$export->addFileXMl14($dir, 'Language', 'lang', 'id_lang', false))
                    $this->_errors[] = $this->l('Cannot create Language.xml');
                else
                    $this->insertTableExported($dir, 'lang');
            }
            if ($this->checkTableExported($dir, 'currency')) {
                if (!$export->addFileXMl14($dir, 'Currency', 'currency', 'id_currency', false))
                    $this->_errors[] = $this->l('Cannot create Currency.xml');
                else
                    $this->insertTableExported($dir, 'currency');
            }
            if ($this->checkTableExported($dir, 'zone')) {
                if (!$export->addFileXMl14($dir, 'Zone', 'zone', 'id_zone', false))
                    $this->_errors[] = $this->l('Cannot create Zone.xml');
                else
                    $this->insertTableExported($dir, 'zone');
            }
            if ($this->checkTableExported($dir, 'country')) {
                if (!$export->addFileXMl14($dir, 'Country', 'country', 'id_country', true))
                    $this->_errors[] = $this->l('Cannot create Country.xml');
                else
                    $this->insertTableExported($dir, 'country');
            }
            if ($this->checkTableExported($dir, 'state')) {
                if (!$export->addFileXMl14($dir, 'State', 'state', 'id_state', false))
                    $this->_errors[] = $this->l('Cannot create State.xml');
                else
                    $this->insertTableExported($dir, 'state');
            }
            if (in_array('employees', $data_exports)) {
                if ($this->checkTableExported($dir, 'employee')) {
                    if (!$export->addFileXMl14($dir, 'Employee', 'employee', 'id_employee', false))
                        $this->_errors[] = $this->l('Cannot create Employee.xml');
                    else
                        $this->insertTableExported($dir, 'employee');
                }

            }
            if (in_array('categories', $data_exports)) {
                if ($this->checkTableExported($dir, 'group')) {
                    if (!$export->addFileXMl14($dir, 'Group', 'group', 'id_group', true))
                        $this->_errors[] = $this->l('Cannot create Group.xml');
                    else
                        $this->insertTableExported($dir, 'group');
                }
                if ($this->checkTableExported($dir, 'category_group')) {
                    if (!$export->addFileXMl14($dir, 'categorygroup', 'category_group')) {
                        $this->_errors[] = $this->l('Cannot create categorygroup.xml');
                    } else
                        $this->insertTableExported($dir, 'category_group');
                }
                if ($this->checkTableExported($dir, 'category')) {
                    if (!$this->addCategoryFileXMl14($dir, false))
                        $this->_errors[] = $this->l('Cannot create Category.xml');
                    else
                        $this->insertTableExported($dir, 'category');
                }
            }
            if (in_array('customers', $data_exports)) {
                if ($this->checkTableExported($dir, 'group')) {
                    if (!$export->addFileXMl14($dir, 'Group', 'group', 'id_group', true))
                        $this->_errors[] = $this->l('Cannot create Group.xml');
                    else
                        $this->insertTableExported($dir, 'group');
                }
                if ($this->checkTableExported($dir, 'customer')) {
                    if (!$export->addFileXMl14($dir, 'Customer', 'customer', 'id_customer', false))
                        $this->_errors[] = $this->l('Cannot create Customer.xml');
                    else
                        $this->insertTableExported($dir, 'customer');
                }
                if ($this->checkTableExported($dir, 'customer_group')) {
                    if (!$export->addFileXMl14($dir, 'customergroup', 'customer_group')) {
                        $this->_errors[] = $this->l('Cannot create customergroup.xml');
                    } else
                        $this->insertTableExported($dir, 'customer_group');
                }
                if ($this->checkTableExported($dir, 'address')) {
                    if (!$export->addFileXMl14($dir, 'Address', 'address', 'id_address', false))
                        $this->_errors[] = $this->l('Cannot create Address.xml');
                    else
                        $this->insertTableExported($dir, 'address');
                }
            }
            if (in_array('manufactures', $data_exports)) {
                if ($this->checkTableExported($dir, 'manufacturer')) {
                    if (!$export->addFileXMl14($dir, 'Manufacturer', 'manufacturer', 'id_manufacturer', true))
                        $this->_errors[] = $this->l('Cannot create Manufacturer.xml');
                    else
                        $this->insertTableExported($dir, 'manufacturer');
                }
            }
            if (in_array('suppliers', $data_exports)) {
                if ($this->checkTableExported($dir, 'supplier')) {
                    if (!$export->addFileXMl14($dir, 'Supplier', 'supplier', 'id_supplier', true))
                        $this->_errors[] = $this->l('Cannot create Supplier.xml');
                    else
                        $this->insertTableExported($dir, 'supplier');
                }
            }
            if (in_array('carriers', $data_exports)) {
                if ($this->checkTableExported($dir, 'carrier')) {
                    if (!$export->addFileXMl14($dir, 'Carrier', 'carrier', 'id_carrier', true))
                        $this->_errors[] = $this->l('Cannot create Carrier.xml');
                    else
                        $this->insertTableExported($dir, 'carrier');
                }
                if ($this->checkTableExported($dir, 'carrier_zone')) {
                    if (!$export->addFileXMl14($dir, 'carrierzone', 'carrier_zone')) {
                        $this->_errors[] = $this->l('Cannot create carrierzone.xml');
                    } else
                        $this->insertTableExported($dir, 'carrier_zone');
                }
                if ($this->checkTableExported($dir, 'carrier_group')) {
                    if (!$export->addFileXMl14($dir, 'carriergroup', 'carrier_group')) {
                        $this->_errors[] = $this->l('Cannot create carriergroup.xml');
                    } else
                        $this->insertTableExported($dir, 'carrier_group');
                }
                if ($this->checkTableExported($dir, 'range_price')) {
                    if (!$export->addFileXMl14($dir, 'RangePrice', 'range_price', 'id_range_price', false))
                        $this->_errors[] = $this->l('Cannot create RangePrice.xml');
                    else
                        $this->insertTableExported($dir, 'range_price');
                }
                if ($this->checkTableExported($dir, 'range_weight')) {
                    if (!$export->addFileXMl14($dir, 'RangeWeight', 'range_weight', 'id_range_weight', false))
                        $this->_errors[] = $this->l('Cannot create RangeWeight.xml');
                    else
                        $this->insertTableExported($dir, 'range_weight');
                }
                if ($this->checkTableExported($dir, 'delivery')) {
                    if (!$export->addFileXMl14($dir, 'Delivery', 'delivery', 'id_delivery', false))
                        $this->_errors[] = $this->l('Cannot create Delivery.xml');
                    else
                        $this->insertTableExported($dir, 'delivery');
                }
            }
            if (in_array('vouchers', $data_exports)) {
                if ($this->checkTableExported($dir, 'discount')) {
                    if (!$export->addFileXMl14($dir, 'Discount', 'discount', 'id_discount', true))
                        $this->_errors[] = $this->l('Cannot create Discount.xml');
                    else
                        $this->insertTableExported($dir, 'discount');
                }
                if ($this->checkTableExported($dir, 'discount_type')) {
                    if (!$export->addFileXMl14($dir, 'DiscountType', 'discount_type', 'id_discount_type', true))
                        $this->_errors[] = $this->l('Cannot create DiscountType.xml');
                    else
                        $this->insertTableExported($dir, 'discount_type');
                }
            }
            if (in_array('products', $data_exports)) {
                if ($this->checkTableExported($dir, 'category_product')) {
                    if (!$export->addFileXMl14($dir, 'categoryproduct', 'category_product')) {
                        $this->_errors[] = $this->l('Cannot create categoryproduct.xml');  //extra
                    } else
                        $this->insertTableExported($dir, 'category_product');
                }
                if ($this->checkTableExported($dir, 'product')) {
                    if (!$export->addFileXMl14($dir, 'Product', 'product', 'id_product', true))
                        $this->_errors[] = $this->l('Cannot create Product.xml');
                    else
                        $this->insertTableExported($dir, 'product');
                }
                if ($this->checkTableExported($dir, 'tag')) {
                    if (!$export->addFileXMl14($dir, 'Tag', 'tag', 'id_tag'))
                        $this->_errors[] = $this->l('Cannot create Tag.xml');
                    else
                        $this->insertTableExported($dir, 'tag');
                }
                if ($this->checkTableExported($dir, 'image')) {
                    if (!$export->addFileXMl14($dir, 'Image', 'image', 'id_image', true))
                        $this->_errors[] = $this->l('Cannot create Image.xml');
                    else
                        $this->insertTableExported($dir, 'image');
                }
                if ($this->checkTableExported($dir, 'product_attribute')) {
                    if (!$export->addFileXMl14($dir, 'Combination', 'product_attribute', 'id_product_attribute', false))
                        $this->_errors[] = $this->l('Cannot create Combination.xml');
                    else
                        $this->insertTableExported($dir, 'product_attribute');
                }
                if ($this->checkTableExported($dir, 'attribute_group')) {
                    if (!$export->addFileXMl14($dir, 'AttributeGroup', 'attribute_group', 'id_attribute_group', true))
                        $this->_errors[] = $this->l('Cannot create AttributeGroup.xml');
                    else
                        $this->insertTableExported($dir, 'attribute_group');
                }
                if ($this->checkTableExported($dir, 'attribute')) {
                    if (!$export->addFileXMl14($dir, 'Attribute', 'attribute', 'id_attribute', true))
                        $this->_errors[] = $this->l('Cannot create Attribute.xml');
                    else
                        $this->insertTableExported($dir, 'attribute');
                }
                if ($this->checkTableExported($dir, 'product_attribute_combination')) {
                    if (!$export->addFileXMl14($dir, 'productattributecombination', 'product_attribute_combination')) {
                        $this->_errors[] = $this->l('Cannot create productattributecombination.xml'); //extra
                    } else
                        $this->insertTableExported($dir, 'product_attribute_combination');
                }
                if ($this->checkTableExported($dir, 'product_attribute_image')) {
                    if (!$export->addFileXMl14($dir, 'productattributeimage', 'product_attribute_image')) {
                        $this->_errors[] = $this->l('Cannot create productattributeimage.xml'); //extra
                    } else
                        $this->insertTableExported($dir, 'product_attribute_image');
                }
                if ($this->checkTableExported($dir, 'product_tag')) {
                    if (!$export->addFileXMl14($dir, 'producttag', 'product_tag')) {
                        $this->_errors[] = $this->l('Cannot create producttag.xml'); //extra
                    } else
                        $this->insertTableExported($dir, 'product_tag');
                }
                if ($this->checkTableExported($dir, 'feature')) {
                    if (!$export->addFileXMl14($dir, 'Feature', 'feature', 'id_feature', true))
                        $this->_errors[] = $this->l('Cannot create Feature.xml');
                    else
                        $this->insertTableExported($dir, 'feature');
                }
                if ($this->checkTableExported($dir, 'feature_value')) {
                    if (!$export->addFileXMl14($dir, 'FeatureValue', 'feature_value', 'id_feature_value', true))
                        $this->_errors[] = $this->l('Cannot create FeatureValue.xml');
                    else
                        $this->insertTableExported($dir, 'feature_value');
                }
                if ($this->checkTableExported($dir, 'feature_product')) {
                    if (!$export->addFileXMl14($dir, 'featureproduct', 'feature_product')) {
                        $this->_errors[] = $this->l('Cannot create featureproduct.xml'); // extra feature_product;
                    } else
                        $this->insertTableExported($dir, 'feature_product');
                }
                if ($this->checkTableExported($dir, 'specific_price')) {
                    if (!$export->addFileXMl14($dir, 'SpecificPrice', 'specific_price', 'id_specific_price', false))
                        $this->_errors[] = $this->l('Cannot create SpecificPrice.xml');
                    else
                        $this->insertTableExported($dir, 'specific_price');
                }
                if ($this->checkTableExported($dir, 'tax')) {
                    if (!$export->addFileXMl14($dir, 'Tax', 'tax', 'id_tax', true))
                        $this->_errors[] = $this->l('Cannot create Tax.xml');
                    else
                        $this->insertTableExported($dir, 'tax');
                }
                if ($this->checkTableExported($dir, 'tax_rules_group')) {
                    if (!$export->addFileXMl14($dir, 'TaxRulesGroup', 'tax_rules_group', 'id_tax_rules_group', false))
                        $this->_errors[] = $this->l('Cannot create TaxRulesGroup.xml');
                    else
                        $this->insertTableExported($dir, 'tax_rules_group');
                }
                if ($this->checkTableExported($dir, 'tax_rule')) {
                    if (!$export->addFileXMl14($dir, 'TaxRule', 'tax_rule', 'id_tax_rule', false))
                        $this->_errors[] = $this->l('Cannot create TaxRule.xml');
                    else
                        $this->insertTableExported($dir, 'tax_rule');
                }
                if ($this->checkTableExported($dir, 'customization_field')) {
                    if (!$export->addFileXMl14($dir, 'CustomizationField', 'customization_field', 'id_customization_field', true))
                        $this->_errors[] = $this->l('Cannot create CustomizationField.xml');
                    else
                        $this->insertTableExported($dir, 'customization_field');
                }
                if ($this->checkTableExported($dir, 'accessory')) {
                    if (!$export->addFileXMl14($dir, 'accessory', 'accessory')) {
                        $this->_errors[] = $this->l('Cannot create accessory.xml'); //extra
                    } else
                        $this->insertTableExported($dir, 'accessory');
                }
            }
            if (in_array('orders', $data_exports)) {
                if ($this->checkTableExported($dir, 'order_state')) {
                    if (!$export->addFileXMl14($dir, 'OrderState', 'order_state', 'id_order_state', true))
                        $this->_errors[] = $this->l('Cannot create OrderState.xml');
                    else
                        $this->insertTableExported($dir, 'order_state');
                }
                if ($this->checkTableExported($dir, 'cart')) {
                    if (!$export->addFileXMl14($dir, 'Cart', 'cart', 'id_cart', false))
                        $this->_errors[] = $this->l('Cannot create Cart.xml');
                    else
                        $this->insertTableExported($dir, 'cart');
                }
                if ($this->checkTableExported($dir, 'customization')) {
                    if (!$export->addFileXMl14($dir, 'Customization', 'customization', 'id_customization'))
                        $this->_errors[] = $this->l('Cannot create CustomizationField.xml');
                    else
                        $this->insertTableExported($dir, 'customization');
                }
                if ($this->checkTableExported($dir, 'customized_data')) {
                    if (!$export->addFileXMl14($dir, 'customizeddata', 'customized_data'))
                        $this->_errors[] = $this->l('Cannot create customizeddata.xml');
                    else
                        $this->insertTableExported($dir, 'customized_data');
                }
                if ($this->checkTableExported($dir, 'orders')) {
                    if (!$export->addFileXMl14($dir, 'Order', 'orders', 'id_order', false))
                        $this->_errors[] = $this->l('Cannot create Order.xml');
                    else
                        $this->insertTableExported($dir, 'orders');
                }
                if ($this->checkTableExported($dir, 'order_detail')) {
                    if (!$export->addFileXMl14($dir, 'OrderDetail', 'order_detail', 'id_order_detail', false))
                        $this->_errors[] = $this->l('Cannot create OrderDetail.xml');
                    else
                        $this->insertTableExported($dir, 'order_detail');
                }
                if ($this->checkTableExported($dir, 'order_slip')) {
                    if (!$export->addFileXMl14($dir, 'OrderSlip', 'order_slip', 'id_order_slip', false))
                        $this->_errors[] = $this->l('Cannot create OrderSlip.xml');
                    else
                        $this->insertTableExported($dir, 'order_slip');
                }
                if ($this->checkTableExported($dir, 'order_history')) {
                    if (!$export->addFileXMl14($dir, 'OrderHistory', 'order_history', 'id_order_history', false))
                        $this->_errors[] = $this->l('Cannot create OrderHistory.xml');
                    else
                        $this->insertTableExported($dir, 'order_history');
                }
                if ($this->checkTableExported($dir, 'order_message')) {
                    if (!$export->addFileXMl14($dir, 'OrderMessage', 'order_message', 'id_order_message', true))
                        $this->_errors[] = $this->l('Cannot create OrderMessage.xml');
                    else
                        $this->insertTableExported($dir, 'order_message');
                }
                if ($this->checkTableExported($dir, 'order_return')) {
                    if (!$export->addFileXMl14($dir, 'OrderReturn', 'order_return', 'id_order_return', false))
                        $this->_errors[] = $this->l('Cannot create OrderReturn.xml');
                    else
                        $this->insertTableExported($dir, 'order_return');
                }
                if ($this->checkTableExported($dir, 'message')) {
                    if (!$export->addFileXMl14($dir, 'Message', 'message', 'id_message', false))
                        $this->_errors[] = $this->l('Cannot create Message.xml');
                    else
                        $this->insertTableExported($dir, 'message');
                }
            }
            if (in_array('CMS_categories', $data_exports)) {
                if ($this->checkTableExported($dir, 'cms_category')) {
                    if (!$export->addFileXMl14($dir, 'CMSCategory', 'cms_category', 'id_cms_category', true))
                        $this->_errors[] = $this->l('Cannot create CMSCategory.xml');
                    else
                        $this->insertTableExported($dir, 'cms_category');
                }

            }
            if (in_array('CMS', $data_exports)) {
                if ($this->checkTableExported($dir, 'cms')) {
                    if (!$export->addFileXMl14($dir, 'CMS', 'cms', 'id_cms', true))
                        $this->_errors[] = $this->l('Cannot create CMS.xml');
                    else
                        $this->insertTableExported($dir, 'cms');
                }

            }
            if (in_array('messages', $data_exports)) {
                if ($this->checkTableExported($dir, 'contact')) {
                    if (!$export->addFileXMl14($dir, 'Contact', 'contact', 'id_contact', true))
                        $this->_errors[] = $this->l('Cannot create Contact.xml');
                    else
                        $this->insertTableExported($dir, 'contact');
                }
                if ($this->checkTableExported($dir, 'customer_thread')) {
                    if (!$export->addFileXMl14($dir, 'CustomerThread', 'customer_thread', 'id_customer_thread', false))
                        $this->_errors[] = $this->l('Cannot create CustomerThread.xml');
                    else
                        $this->insertTableExported($dir, 'customer_thread');
                }
                if ($this->checkTableExported($dir, 'customer_message')) {
                    if (!$export->addFileXMl14($dir, 'CustomerMessage', 'customer_message', 'id_customer_message', false))
                        $this->_errors[] = $this->l('Cannot create CustomerMessage.xml');
                    else
                        $this->insertTableExported($dir, 'customer_message');
                }

            }
            if (!$this->_errors) {
                $this->zipForderXml($zip_file_name);
                $content = $this->exportContent();
                $this->context->cookie->zip_file_name = '';
                $this->context->cookie->write();
                $this->deleteForderXml($zip_file_name);
            }
        }
        return $this->_errors;
    }

    public function genSecure($size)
    {
        $chars = md5(time());
        $code = '';
        for ($i = 1; $i <= $size; ++$i) {
            $char = Tools::substr($chars, rand(0, Tools::strlen($chars) - 1), 1);
            if ($char == 'e')
                $char = 'a';
            $code .= $char;
        }

        return $code;
    }

    public static function upperFirstChar($t)
    {
        return Tools::ucfirst($t);
    }

    public function downloadFileZip($zip_file_name)
    {
        $cacheDir = dirname(__FILE__) . '/cache/export/';
        ob_end_clean();
        ob_clean();
        header("Pragma: public"); // required
        header("Expires: 0");
        header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
        header("Cache-Control: private", false); // required for certain browsers
        header("Content-Transfer-Encoding: binary");
        header("Content-Length: " . filesize($cacheDir . $zip_file_name));
        header("Content-type: application/zip");
        header("Content-Disposition: attachment; filename=$zip_file_name");
        readfile($cacheDir . $zip_file_name);
        unlink($cacheDir . $zip_file_name);
        exit();
    }

    public function zipForderXml($file_name)
    {

        $dir_forder = dirname(__FILE__) . '/cache/export/';
        $rootPath = realpath($dir_forder . $file_name);
        $zip = new ZipArchive();
        $zip->open($dir_forder . $file_name . '.zip', ZipArchive::CREATE | ZipArchive::OVERWRITE);
        // Create recursive directory iterator
        /** @var SplFileInfo[] $files */
        $files = new RecursiveIteratorIterator(

            new RecursiveDirectoryIterator($rootPath),
            RecursiveIteratorIterator::LEAVES_ONLY
        );
        foreach ($files as $name => $file) {
            if (!$file->isDir()) {
                $filePath = $file->getRealPath();
                $relativePath = substr($filePath, strlen($rootPath) + 1);
                $zip->addFile($filePath, $relativePath);
            }
        }
        $zip->close();
    }

    public function deleteForderXml($file_name)
    {
        $this->context->cookie->export_sucss = 1;

        $this->context->cookie->write();

        $dir_forder = dirname(__FILE__) . '/cache/export/';
        if (!is_dir($dir_forder . $file_name))
            return true;
        foreach (glob($dir_forder . $file_name . '/*.*') as $filename) {
            @unlink($filename);
        }
        @rmdir($dir_forder . $file_name);
        if (ob_get_length() > 0) {
            ob_end_clean();
        }
        die(Tools::jsonEncode(
            array(
                'link_site_connector' => $this->getBaseLink() . 'modules/ets_pres2presconnector/cache/export/' . $file_name . '.zip',
            )
        ));
        return true;

    }

    public function ajaxPercentageExport()
    {
        if (ob_get_length() > 0) {
            ob_end_clean();
        }
        if (Tools::getValue('zip_file_name'))
            $zip_file_name = Tools::getValue('zip_file_name');
        elseif (isset($this->context->cookie->zip_file_name) && $this->context->cookie->zip_file_name)
            $zip_file_name = $this->context->cookie->zip_file_name;
        if (isset($zip_file_name) && $zip_file_name) {
            $dir = dirname(__FILE__) . '/cache/export/' . $zip_file_name;
            if (file_exists($dir . '/totalexport.txt'))
                $totalItemExport = (int)file_get_contents($dir . '/totalexport.txt');
            else
                $totalItemExport = 0;
            if (file_exists($dir . '/export.txt'))
                $totalItemExported = (int)file_get_contents($dir . '/export.txt');
            else
                $totalItemExported = 0;
            if ($totalItemExport && $totalItemExported) {
                die(
                Tools::jsonEncode(
                    array(
                        'percent' => (float)round($totalItemExported * 100 / $totalItemExport, 2),
                        'table' => file_get_contents($dir . '/table_export.txt'),
                        'totalItemExport' => $totalItemExport,
                        'totalItemExported' => $totalItemExported,
                        'file' => $this->context->cookie->zip_file_name,
                    )
                )
                );
            } else {
                die(
                Tools::jsonEncode(
                    array(
                        'percent' => 100,
                    )
                )
                );
            }

        }
        die(
        die(
        Tools::jsonEncode(
            array(
                'percent' => 100,
            )
        )
        )
        );
    }

    public function addCategoryFileXMl($dir, $multishop)
    {
        $roots = Db::getInstance()->executeS('SELECT c.id_category FROM ' . _DB_PREFIX_ . 'category c,' . _DB_PREFIX_ . 'category_shop cs  where c.id_category=cs.id_category AND c.id_parent=0 group by c.id_category');
        $xml_output = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
        $xml_output .= '<entity_profile>' . "\n";
        if ($roots) {
            foreach ($roots as $root) {
                $this->getXMlCategoriesTree($root['id_category'], $xml_output, $multishop);
            }
        }
        $xml_output .= '</entity_profile>';
        if (!file_exists($dir . '/Category.xml')) {
            Configuration::updateValue('ETS_TABLE_EXPORT', 'category');
            file_put_contents($dir . '/Category.xml', $xml_output);
        }
        return true;
    }

    public function addCategoryFileXMl14($dir, $multishop)
    {
        $roots = Db::getInstance()->executeS('SELECT c.id_category FROM ' . _DB_PREFIX_ . 'category c  WHERE c.id_parent=0 group by c.id_category');
        $xml_output = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
        $xml_output .= '<entity_profile>' . "\n";
        if ($roots) {
            foreach ($roots as $root) {
                $this->getXMlCategoriesTree($root['id_category'], $xml_output, true);
            }
        }
        $xml_output .= '</entity_profile>';
        if (!file_exists($dir . '/Category.xml')) {
            Configuration::updateValue('ETS_TABLE_EXPORT', 'category');
            file_put_contents($dir . '/Category.xml', $xml_output);
        }
        return true;
    }

    public function getXMlCategoriesTree($id_root, &$xml_output, $multishop)
    {
        $sql = "SELECT c.*
        FROM " . _DB_PREFIX_ . "category c " . (version_compare(_PS_VERSION_, '1.5', '>=') ? "INNER JOIN " . _DB_PREFIX_ . "category_shop cs on (c.id_category =cs.id_category " . (!$multishop ?
                    ' AND cs.id_shop="' . (int)$this->context->shop->id . '"' : '') . ")" : "") . "
        WHERE c.id_category = " . (int)$id_root .
            " GROUP BY c.id_category";
        $ssl = (Configuration::get('PS_SSL_ENABLED'));
        if ($this->pres_version == 1.4)
            $base = $ssl ? 'https://' . Configuration::get('PS_SHOP_DOMAIN_SSL') : 'http://' . Configuration::get('PS_SHOP_DOMAIN');
        else
            $base = $ssl ? 'https://' . $this->context->shop->domain_ssl : 'http://' . $this->context->shop->domain;
        if ($category = Db::getInstance()->getRow($sql)) {
            $xml_output .= '<category>';
            if ($this->pres_version == 1.4)
                $type_category_default = '';
            else
                $type_category_default = ImageType::getFormatedName('category');
            if ($this->pres_version == 1.4)
                $type_medium_default = '';
            else
                $type_medium_default = ImageType::getFormatedName('medium');
            if (file_exists(_PS_CAT_IMG_DIR_ . (int)$id_root . '.jpg')) {
                $url = $base . __PS_BASE_URI__ . 'img/c/' . $id_root . '.jpg';
                $xml_output .= '<link_image><![CDATA[' . $url . ']]></link_image>' . "\n";
            } elseif (file_exists(_PS_CAT_IMG_DIR_ . (int)$id_root . '-' . $type_category_default . '.jpg')) {
                $url = $base . __PS_BASE_URI__ . 'img/c/' . $id_root . '-' . $type_category_default . '.jpg';
                $xml_output .= '<link_image><![CDATA[' . $url . ']]></link_image>' . "\n";
            } elseif (file_exists(_PS_CAT_IMG_DIR_ . (int)$id_root . '-' . $type_medium_default . '.jpg')) {
                $url = $base . __PS_BASE_URI__ . 'img/c/' . $id_root . '-' . $type_medium_default . '.jpg';
                $xml_output .= '<link_image><![CDATA[' . $url . ']]></link_image>' . "\n";
            }
            if (file_exists(_PS_CAT_IMG_DIR_ . (int)$id_root . '_thumb.jpg')) {
                $url = $base . __PS_BASE_URI__ . 'img/c/' . $id_root . '_thumb.jpg';
                $xml_output .= '<link_thumb><![CDATA[' . $url . ']]></link_thumb>' . "\n";
            }
            foreach ($category as $key => $value) {
                $xml_output .= '<' . $key . '><![CDATA[' . $value . ']]></' . $key . '>' . "\n";
            }
            $datalanguages = Db::getInstance()->executeS('SELECT cl.*,l.iso_code FROM ' . _DB_PREFIX_ . 'category_lang cl,' . _DB_PREFIX_ .
                'lang l  WHERE cl.id_lang=l.id_lang AND cl.id_category=' . (int)$id_root . (!$multishop ?
                    ' AND cl.id_shop="' . (int)Context::getContext()->shop->id . '"' : ''));
            if ($datalanguages && $datalanguages) {
                foreach ($datalanguages as $datalanguage) {
                    $xml_output .= '<datalanguage iso_code="' . $datalanguage['iso_code'] . '"' . ($datalanguage['id_lang'] ==
                        Configuration::get('PS_LANG_DEFAULT') ? ' default="1"' : '') . ' >' . "\n";
                    if ($datalanguage) {
                        foreach ($datalanguage as $key => $value) {
                            if ($key != 'iso_code') {
                                $xml_output .= '<' . $key . '><![CDATA[' . $value . ']]></' . $key . '>' . "\n";
                            }
                        }
                    }
                    $xml_output .= '</datalanguage>' . "\n";
                }
            }
            if (version_compare(_PS_VERSION_, '1.5', '>=')) {
                $datashops = Db::getInstance()->executeS('SELECT s.id_shop,cs.* FROM ' . _DB_PREFIX_ . 'shop s ,' . _DB_PREFIX_ .
                    'category_shop cs WHERE s.id_shop=cs.id_shop AND cs.id_category=' . (int)$id_root .
                    (!$multishop ? ' AND cs.id_shop="' . (int)Context::getContext()->shop->id . '"' :
                        ''));
                if ($datashops && $datashops) {
                    foreach ($datashops as $shop) {
                        $xml_output .= '<datashop id_shop="' . $shop['id_shop'] . '"';
                        $xml_output .= '></datashop>' . "\n";
                    }
                }
            }
            $xml_output .= '</category>';
            $children = $this->getChildrenCategories2($id_root, $multishop);
            if ($children) {
                foreach ($children as $child) {
                    $this->getXMlCategoriesTree($child['id_category'], $xml_output, $multishop);
                }
            }
        }
    }

    public function getChildrenCategories2($id_root, $multishop)
    {
        $sql = "SELECT c.id_category
                FROM " . _DB_PREFIX_ . "category c
                " . (version_compare(_PS_VERSION_, '1.5', '>=') ? "INNER JOIN " . _DB_PREFIX_ . "category_shop cs on (c.id_category =cs.id_category " . (!$multishop ? ' AND cs.id_shop="' . (int)$this->context->shop->id . '"' : '') . ")" : "") . "
                WHERE c.id_parent = " . (int)$id_root . " GROUP BY c.id_category";
        return Db::getInstance()->executeS($sql);
    }

    public function checkTableExported($dir, $table)
    {
        if (file_exists($dir . '/table_exported.txt')) {
            $imported = file_get_contents($dir . '/table_exported.txt');
            if (in_array($table, explode(',', $imported)))
                return false;
        }
        return true;
    }

    public function insertTableExported($dir, $table)
    {
        if (file_exists($dir . '/table_exported.txt')) {
            $imported = file_get_contents($dir . '/table_exported.txt');
            $imported .= ',' . $table;
            file_put_contents($dir . '/table_exported.txt', $imported);

        } else
            file_put_contents($dir . '/table_exported.txt', $table);
    }

    public static function usingSecureMode()
    {
        if (isset($_SERVER['HTTPS']))
            return ($_SERVER['HTTPS'] == 1 || strtolower($_SERVER['HTTPS']) == 'on');
        // $_SERVER['SSL'] exists only in some specific configuration
        if (isset($_SERVER['SSL']))
            return ($_SERVER['SSL'] == 1 || strtolower($_SERVER['SSL']) == 'on');
        // $_SERVER['REDIRECT_HTTPS'] exists only in some specific configuration
        if (isset($_SERVER['REDIRECT_HTTPS']))
            return ($_SERVER['REDIRECT_HTTPS'] == 1 || strtolower($_SERVER['REDIRECT_HTTPS']) == 'on');

        return false;
    }
}